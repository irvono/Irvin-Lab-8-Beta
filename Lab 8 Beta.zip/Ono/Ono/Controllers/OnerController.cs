﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Ono.DAL;
using Ono.Models;

namespace Ono.Controllers
{
    public class OnerController : Controller
    {
        private IOnerRepository onerRepository;

        public OnerController()
        {
            this.onerRepository = new OnerRepository(new OnoContext());
        }

        // called by unit tests
        public OnerController(IOnerRepository onerRepository)
        {
            this.onerRepository = onerRepository;
        }
        //private OnoContext db = new OnoContext();

        // GET: User
        public ActionResult Index()
        {
            return View(onerRepository.GetOners());
        }

        // GET: User/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            //User user = db.Users.Find(id);
            Oner oner = onerRepository.GetOnerByID((int)id);
            if (oner == null)
            {
                return HttpNotFound();
            }
            return View(oner);
        }

        // GET: User/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: User/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "OnerID,LastName,FirstName,Email,Skill,Password,Address,Phone")] Oner oner)
        {
            if (ModelState.IsValid)
            {
                onerRepository.InsertOner(oner);
                onerRepository.Save();
                return RedirectToAction("Index");
            }

            return View(oner);
        }

        // GET: User/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Oner oner = onerRepository.GetOnerByID((int)id);
            if (oner == null)
            {
                return HttpNotFound();
            }
            return View(oner);
        }

        // POST: User/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "OnerID,LastName,FirstName,Email,Skill,Password,Address,Phone")] Oner oner)
        {
            if (ModelState.IsValid)
            {
                //db.Entry(user).State = EntityState.Modified;
                onerRepository.UpdateOner(oner);
                onerRepository.Save();
                return RedirectToAction("Index");
            }
            return View(oner);
        }

        // GET: User/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Oner oner = onerRepository.GetOnerByID((int)id);
            if (oner == null)
            {
                return HttpNotFound();
            }
            return View(oner);
        }

        // POST: User/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            //User user = userRepository.GetUserByID(id);
            onerRepository.DeleteOner(id);
            onerRepository.Save();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                onerRepository.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
