﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ono.Models
{
    public class Photo : IEntityModel
    {

        public int PhotoID { get; set; }
        public string Name { get; set; }
        public int AlbumID { get; set; }
        public int OnerID { get; set; }

        //public virtual ICollection<Album> Albums { get; set; }

        //public virtual User User { get; set; }
    }
}
