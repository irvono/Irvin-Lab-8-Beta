﻿using Ono.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ono.DAL
{
    public class UnitOfWork : IUnitOfWork
    {
        public class UnitOfWork : IUnitOfWork
        {
            private OnoContext context = new OnoContext();
            private IOnerRepository<Oner> onerRepo;
            private IOnerRepository<Album> albumRepo;
            private IOnerRepository<Photo> photoRepo;
            private IOnerRepository<Event> eventRepo;
            private IOnerRepository<Genre> genreRepo;
            private IOnerRepository<Video> videoRepo;


            public IOnerRepository<Models.Oner> OnerRepo
            {
                get
                {
                    if (this.onerRepo == null)
                    {
                        this.onerRepo = new OnerRepository<Oner>(context);
                    }
                    return onerRepo;
                }
            }

            public IOnerRepository<Album> AlbumRepo
            {
                get
                {
                    if (this.albumRepo == null)
                    {
                        this.albumRepo = new OnerRepository<Album>(context);
                    }
                    return albumRepo;
                }
            }

            public IOnerRepository<Photo> PhotoRepo
            {
                get
                {
                    if (this.photoRepo == null)
                    {
                        this.photoRepo = new OnerRepository<Photo>(context);
                    }
                    return photoRepo;
                }
            }

            public IOnerRepository<Event> EventRepo
            {
                get
                {
                    if (this.eventRepo == null)
                    {
                        this.eventRepo = new OnerRepository<Event>(context);
                    }
                    return eventRepo;
                }
            }

            public IOnerRepository<Genre> GenreRepo
            {
                get
                {
                    if (this.genreRepo == null)
                    {
                        this.genreRepo = new OnerRepository<Genre>(context);
                    }
                    return genreRepo;
                }
            }
            public IOnerRepository<Video> VideoRepo
            {
                get
                {
                    if (this.videoRepo == null)
                    {
                        this.videoRepo = new OnerRepository<Video>(context);
                    }
                    return videoRepo;
                }
            }

            public void Save()
            {
                context.SaveChanges();
            }

            private bool disposed = false;

            protected virtual void Dispose(bool disposing)
            {
                if (!this.disposed)
                {
                    if (disposing)
                    {
                        context.Dispose();
                    }
                }
                this.disposed = true;
            }

            public void Dispose()
            {
                Dispose(true);
                GC.SuppressFinalize(this);
            }
        }
    }
}
